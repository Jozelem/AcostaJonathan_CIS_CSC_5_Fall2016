/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 17, 2018, 11:50 PM
 * Purpose: Average of Values
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 


//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float numFst,  //The first number in a number series
          numSc,   //The second number in a number series
          numThr,  //The third number in a number series
          numFrth, //The fourth number in a number series 
          numFfth, //The fifth number in a number series
          sum;     //The sum of all the number
    float avrgV;   //The average Value of the number series
    
    //Initial Variables
    numFst=28.0f;
    numSc=32.0f;
    numThr=37.0f;
    numFrth=24.0f;
    numFfth=33.0f;
   
    //Map/Process Inputs to Outputs
    sum=numFst+numSc+numThr+numFrth+numFfth;
    avrgV=sum/5;
    
    //Display Outputs
    cout<<"The First Number in a Number Series = "<<numFst<<endl;
    cout<<"The Second Number in a Number Series = "<<numSc<<endl;
    cout<<"The Third Number in a Number Series = "<<numThr<<endl;
    cout<<"The Fourth Number in a Number Series = "<<numFrth<<endl;
    cout<<"The Fifth Number in a Number Series = "<<numFfth<<endl;
    cout<<"The Average Value of the Number Series = "<<avrgV<<endl;
    
    //Exit Program!
    return 0;
}

