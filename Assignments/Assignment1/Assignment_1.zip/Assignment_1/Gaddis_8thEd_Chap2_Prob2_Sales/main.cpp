/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 15, 2018, 12:05 AM
 * Purpose: Sales Prediction
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 
const int PERCENT=100;    //Conversion for a percent 
const float MLLN=1.0e06f; //Million

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float comPcnt;   //Percent of Total sales
    float sales; //Sales this Years
    int mnyGnrt;   //The money generate
    
    //Initial Variables
    comPcnt=0.58f;
    sales=8.6*MLLN;
    
    //Map/Process Inputs to Outputs
    mnyGnrt=sales*comPcnt;
    
    //Display Outputs
    cout<<"Total Sales percent = "<<comPcnt*PERCENT<<"%"<<endl;
    cout<<"Total Sales = $"<<sales/MLLN<<" Million"<<endl;
    cout<<"Total Money Generated = $"<<mnyGnrt<<endl;
    
    //Exit Program!
    return 0;
}

