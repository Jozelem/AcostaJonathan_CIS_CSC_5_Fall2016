/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 17, 2018, 11:03 PM
 * Purpose: Sales Tax
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 
const int PERCENT=100; //Conversion for a Percent

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float stTax,     //State Sales Tax in percentage
          cntTax,    //County sales Tax in percentage
          totTax;    //Total Sales Tax in dollars
    short int prch;  //Purchase in dollars
    //Initial Variables
    stTax=0.04f;
    cntTax=0.02f;
    prch=95;
    
    //Map/Process Inputs to Outputs
    totTax=(prch*stTax)+(prch*cntTax);
    
    //Display Outputs
    cout<<"Value of Item Purchase = $"<<prch<<endl;
    cout<<"State Sales Tax = "<<stTax*PERCENT<<"%"<<endl;
    cout<<"County Sales Tax = "<<cntTax*PERCENT<<"%"<<endl;
    cout<<"Total Sales Tax = $"<<totTax<<endl;
    
    //Exit Program!
    return 0;
}

