/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 18, 2018, 8:06 PM
 * Purpose: Circuit Board Price
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
#include <iomanip>  //to set to the nerest tenth
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 
const int PERCENT=100; //conversion to percentage

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float profit,  //Percentage of profit earn for each product
          prCrt,   //Cost of a circuit board in dollars
          sllPr;   //Selling price of circuit board
    
    //Initial Variables
    profit=0.35;
    prCrt=14.95;
            
    //Map/Process Inputs to Outputs
    sllPr=(profit*prCrt)+prCrt;
    
    //Display Outputs
    cout<<"Percentage of Profit Earn for each Product ="<<profit<<"%"<<endl;
    cout<<"Cost of a Circuit Board = $"<<prCrt<<endl;
    cout<<"Selling Price of Circuit Board = $"<<fixed<<setprecision(2)<<sllPr<<endl;
    
    //Exit Program!
    return 0;
}

