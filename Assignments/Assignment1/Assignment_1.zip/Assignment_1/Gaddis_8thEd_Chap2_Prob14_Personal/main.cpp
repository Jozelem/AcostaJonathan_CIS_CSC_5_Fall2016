/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 18, 2018, 8:33 PM
 * Purpose: Circuit Board Price
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 


//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string    fName,   //first ame
              lName,   //Last Name 
              nmAdrs,  //Name of street
              city,   
              state,
              cgMayor, //Collage mayor 
              x;       //st.,Ave. ext...   
    int       zpCode,  //ZIP code
              noAdrs,  //number of street
              phone;   //Telephone number
              
    //Initial Variables
    cout<<"Please Enter the Information Bellow"<<endl;
    cout<<"Enter your Name (prest enter after inputing your first name and then  enter your last name)"<<endl;
    cin>>fName;
    cin>>lName;
    cout<<"Enter your Address, start with the number (ex: 523)"<<" After each part press enter"<<endl;
    cin>>noAdrs;
    cout<<"Enter the name of the street (ex: Candy)"<<endl;
    cin>>nmAdrs;
    cout<<"Is it a street or Avenue ext..."<<endl;
    cin>>x;
    cout<<"Your City"<<endl;
    cin>>city;
    cout<<"Your State"<<endl;
    cin>>state;
    cout<<"Your ZIP Code"<<endl;
    cin>>zpCode;
    cout<<"What is your Collage Mayor"<<endl;
    cin>>cgMayor;
    cout<<"Enter your Phone Number (ex:101430234)"<<endl;
    cin>>phone;
    
    //Map/Process Inputs to Outputs
    
    //Display Outputs
    cout<<"The Name Input = "<<fName<<" "<<lName<<endl;
    cout<<"Address Input = "<<noAdrs<<" "<<nmAdrs<<" "<<x<<", "<<city<<", "<<state<<", "<<zpCode<<endl;
    cout<<"The Collage Mayor Input = "<<cgMayor<<endl;
    cout<<"The Phone Number Input = "<<phone<<endl;
    
    //Exit Program!
    return 0;
}

