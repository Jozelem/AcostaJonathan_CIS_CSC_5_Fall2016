/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 15, 2018, 12:05 AM
 * Purpose: Sum of Two Numbers
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    short int fNum,sNum,total;
    
    //Initial Variables
    fNum=50;
    sNum=100;
    
    //Map/Process Inputs to Outputs
    total=fNum+sNum;
    
    //Display Outputs
    cout<<"The fist number ="<<fNum<<endl;
    cout<<"The second number ="<<sNum<<endl;
    cout<<"The Total of the sum of both numbers ="<<total<<endl;
    
    //Exit Program!
    return 0;
}

