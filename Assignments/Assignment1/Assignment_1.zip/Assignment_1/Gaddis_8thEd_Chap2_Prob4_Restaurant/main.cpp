/* 
 * File:   main.cpp
 * Author: Jonathan Acosta
 * Created on February 17, 2018, 11:23 PM
 * Purpose: Restaurant Bill
 */

//system Libraries
#include <iostream> //I/O Library-> cout, endl
#include <iomanip>  //to set to the nerest tenth
using namespace std; //namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array 
const int PERCENT=100; //Conversion of Percent

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float chgMeal, //The cost amount of the meal in dollars
          tax,     //The tax of the meal in percent
          tip,     //tip in percent
          taxMeal, //The meal cost with the tax included
          totBill; //Total bill for the meal in dollars
    
    //Initial Variables
    chgMeal=88.67f;
    tax=0.0675f;
    tip=0.20f;
   
    //Map/Process Inputs to Outputs
    taxMeal=(chgMeal*tax)+chgMeal;
    totBill=(taxMeal*tip)+taxMeal;
    
    //Display Outputs
    cout<<"The cost of the meal = $"<<chgMeal<<endl;
    cout<<"The tax = "<<tax*PERCENT<<"%"<<endl;
    cout<<"The percentage for the tip = "<<tip*PERCENT<<"%"<<endl;
    cout<<"The total bill = $"<<fixed<<setprecision(2)<<totBill<<endl;
    
    //Exit Program!
    return 0;
}

